<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\CoursesRepository")
 */
class Courses
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Name;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Duration;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $Anyo;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->Name;
    }

    public function setName(?string $Name): self
    {
        $this->Name = $Name;

        return $this;
    }

    public function getDuration(): ?string
    {
        return $this->Duration;
    }

    public function setDuration(?string $Duration): self
    {
        $this->Duration = $Duration;

        return $this;
    }

    public function getAnyo(): ?string
    {
        return $this->Anyo;
    }

    public function setAnyo(?string $Anyo): self
    {
        $this->Anyo = $Anyo;

        return $this;
    }
}
